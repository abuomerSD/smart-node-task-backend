const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pos_purchase_order_details', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    purchase_order_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_purchase_orders',
        key: 'id'
      }
    },
    pos_fixed_asset_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    pos_product_unit_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_product_units',
        key: 'id'
      }
    },
    pos_raw_materials_product_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_raw_materials_products',
        key: 'id'
      }
    },
    qty: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    sold_qty: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    unit_price: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    created: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'pos_purchase_order_details',
    timestamps: false,
    indexes: [
      {
        name: "pos_purchases_order_detailes_ibfk_1",
        fields: [
          { name: "purchase_order_id" },
        ]
      },
      {
        name: "record_id",
        fields: [
          { name: "pos_fixed_asset_id" },
        ]
      },
    ]
  });
};

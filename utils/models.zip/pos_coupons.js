const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pos_coupons', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    pos_customer_id: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    pos_coupon_category_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'pos_coupon_categories',
        key: 'id'
      }
    },
    type: {
      type: DataTypes.TINYINT,
      allowNull: false
    },
    value: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    usage_limit: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    used_count: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    is_active: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 1
    },
    valid_from: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    valid_to: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: "0000-00-00 00:00:00"
    },
    created: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'pos_coupons',
    timestamps: false,
    indexes: [
      {
        name: "pos_coupons_ibfk_1",
        fields: [
          { name: "pos_coupon_category_id" },
        ]
      },
    ]
  });
};

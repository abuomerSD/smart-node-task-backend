const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pos_hr_monthly_salaries', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    emp_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_hr_employees',
        key: 'id'
      }
    },
    total_balance: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    paid_balance: {
      type: DataTypes.DECIMAL,
      allowNull: true,
      defaultValue: 0.00
    },
    month: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    year: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    tax: {
      type: DataTypes.DECIMAL,
      allowNull: false
    },
    zakat: {
      type: DataTypes.DECIMAL,
      allowNull: false
    },
    created: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'pos_hr_monthly_salaries',
    timestamps: false,
    indexes: [
      {
        name: "fk_monthly_salaries_emps_1",
        fields: [
          { name: "emp_id" },
        ]
      },
    ]
  });
};

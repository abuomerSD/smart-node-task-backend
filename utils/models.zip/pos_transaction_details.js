const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pos_transaction_details', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    account_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_level_three_chart_of_accounts',
        key: 'id'
      }
    },
    type: {
      type: DataTypes.STRING(20),
      allowNull: false
    },
    value: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    pos_transaction_type: {
      type: DataTypes.STRING(255),
      allowNull: false,
      defaultValue: "normal"
    },
    pos_transaction_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_transactions',
        key: 'id'
      }
    },
    descr: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    descr_en: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    created: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'pos_transaction_details',
    timestamps: false,
    indexes: [
      {
        name: "level_three_accont",
        fields: [
          { name: "account_id" },
        ]
      },
      {
        name: "mian_transation_details",
        fields: [
          { name: "pos_transaction_id" },
        ]
      },
    ]
  });
};

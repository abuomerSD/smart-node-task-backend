const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pos_station_floor_tables', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    floor_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_station_floors',
        key: 'id'
      }
    },
    name: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    seats: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    x: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    y: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    width: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    height: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    color: {
      type: DataTypes.STRING(250),
      allowNull: true
    },
    direction: {
      type: DataTypes.STRING(1),
      allowNull: false,
      defaultValue: "h"
    },
    size: {
      type: DataTypes.STRING(10),
      allowNull: false,
      defaultValue: "small"
    },
    created: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'pos_station_floor_tables',
    timestamps: false,
    indexes: [
      {
        name: "floor_id",
        fields: [
          { name: "floor_id" },
        ]
      },
    ]
  });
};

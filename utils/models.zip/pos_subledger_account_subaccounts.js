const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pos_subledger_account_subaccounts', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    pos_station_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'pos_stations',
        key: 'id'
      }
    },
    pos_subledger_account_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_subledger_accounts',
        key: 'id'
      }
    },
    name: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    name_en: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    pos_level_three_chart_of_account_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_level_three_chart_of_accounts',
        key: 'id'
      }
    },
    is_deletable: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 1
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    created: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'pos_subledger_account_subaccounts',
    timestamps: false,
    indexes: [
      {
        name: "pos_subledger_account_id",
        fields: [
          { name: "pos_subledger_account_id" },
        ]
      },
    ]
  });
};

const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pos_hr_employees', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    pos_hr_department_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'pos_hr_departments',
        key: 'id'
      }
    },
    pos_cash_account_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'pos_cash_accounts',
        key: 'id'
      }
    },
    salaries_payable_subaccount_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_subledger_account_subaccounts',
        key: 'id'
      }
    },
    name: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    birthdate: {
      type: DataTypes.DATEONLY,
      allowNull: false
    },
    basic_salary: {
      type: DataTypes.DECIMAL,
      allowNull: false
    },
    has_tax: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 0
    },
    has_zakat: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 0
    },
    has_attendance: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 1
    },
    created: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'pos_hr_employees',
    timestamps: false,
    indexes: [
      {
        name: "pos_cash_account_id",
        fields: [
          { name: "pos_cash_account_id" },
        ]
      },
      {
        name: "pos_hr_department_id",
        fields: [
          { name: "pos_hr_department_id" },
        ]
      },
      {
        name: "salaries_payable_subaccount_id",
        fields: [
          { name: "salaries_payable_subaccount_id" },
        ]
      },
    ]
  });
};

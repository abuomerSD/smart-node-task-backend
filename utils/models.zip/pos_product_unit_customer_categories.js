const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pos_product_unit_customer_categories', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 0
    },
    pos_customer_category_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_customer_categories',
        key: 'id'
      }
    },
    pos_product_unit_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_product_units',
        key: 'id'
      }
    },
    sale_price: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      defaultValue: 0.00
    },
    created: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'pos_product_unit_customer_categories',
    timestamps: false,
    indexes: [
      {
        name: "pos_product_unit_customer_categories_ibfk_1",
        fields: [
          { name: "pos_customer_category_id" },
        ]
      },
      {
        name: "pos_product_unit_customer_categories_ibfk_2",
        fields: [
          { name: "pos_product_unit_id" },
        ]
      },
    ]
  });
};

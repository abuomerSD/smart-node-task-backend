const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pos_hub_packages_features', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    pos_hub_feature_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'pos_hub_features',
        key: 'id'
      }
    },
    pos_hub_package_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'pos_hub_packages',
        key: 'id'
      }
    },
    created: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'pos_hub_packages_features',
    timestamps: false,
    indexes: [
      {
        name: "pos_hub_subscription_packages_features_ibfk_1",
        fields: [
          { name: "pos_hub_feature_id" },
        ]
      },
      {
        name: "pos_hub_subscription_packages_features_ibfk_2",
        fields: [
          { name: "pos_hub_package_id" },
        ]
      },
    ]
  });
};

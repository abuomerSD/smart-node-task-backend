const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pos_stations', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    pos_hub_manager_id: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    pos_hub_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_hubs',
        key: 'id'
      }
    },
    marketing_campaign_team_member_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    pos_type_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_types',
        key: 'id'
      }
    },
    pos_revenue_categorization_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_revenue_categorization',
        key: 'id'
      }
    },
    single_products_list: {
      type: DataTypes.TINYINT,
      allowNull: true,
      defaultValue: 0
    },
    name: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    has_tax: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 0
    },
    tax_number: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    zakatThreshold: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      defaultValue: 0.00
    },
    tax: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 15
    },
    img: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    posDoc: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    loc: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    lat: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    lng: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    register_number: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    has_shelve: {
      type: DataTypes.TINYINT,
      allowNull: true
    },
    single_floor: {
      type: DataTypes.TINYINT,
      allowNull: true
    },
    price_including_tax: {
      type: DataTypes.TINYINT,
      allowNull: true,
      defaultValue: 0
    },
    has_full_accounting: {
      type: DataTypes.TINYINT,
      allowNull: true
    },
    category_has_image: {
      type: DataTypes.TINYINT,
      allowNull: true
    },
    has_multiple_users: {
      type: DataTypes.TINYINT,
      allowNull: true
    },
    waiters_accounting: {
      type: DataTypes.TINYINT,
      allowNull: true,
      defaultValue: 0
    },
    is_admin_created: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 0
    },
    decrypt_key: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    created: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'pos_stations',
    timestamps: false
  });
};

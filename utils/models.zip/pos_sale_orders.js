const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pos_sale_orders', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    pos_station_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_stations',
        key: 'id'
      }
    },
    pos_user_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_users',
        key: 'id'
      }
    },
    custmor_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_customers',
        key: 'id'
      }
    },
    pos_coupon_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_coupons',
        key: 'id'
      }
    },
    pos_station_floor_table_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_station_floor_tables',
        key: 'id'
      }
    },
    creater_waiter_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_users',
        key: 'id'
      }
    },
    is_delivery: {
      type: DataTypes.TINYINT,
      allowNull: true,
      defaultValue: 0
    },
    payment_time: {
      type: DataTypes.DATE,
      allowNull: true
    },
    bill: {
      type: DataTypes.DECIMAL,
      allowNull: false
    },
    bill_image: {
      type: DataTypes.STRING(250),
      allowNull: true
    },
    created: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'pos_sale_orders',
    timestamps: false,
    indexes: [
      {
        name: "creater_waiter_id",
        fields: [
          { name: "creater_waiter_id" },
        ]
      },
      {
        name: "custmor_id",
        fields: [
          { name: "custmor_id" },
        ]
      },
      {
        name: "pos_sale_orders_ibfk_5",
        fields: [
          { name: "pos_coupon_id" },
        ]
      },
      {
        name: "pos_station_floor_table_id",
        fields: [
          { name: "pos_station_floor_table_id" },
        ]
      },
    ]
  });
};

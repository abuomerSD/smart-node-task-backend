const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pos_budget', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    pos_level_three_chart_of_account_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_level_three_chart_of_accounts',
        key: 'id'
      }
    },
    pos_accounting_period_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_accounting_periods',
        key: 'id'
      }
    },
    value: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    remarks: {
      type: DataTypes.STRING(512),
      allowNull: true
    },
    created: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'pos_budget',
    timestamps: false,
    indexes: [
      {
        name: "accounting_period_id",
        fields: [
          { name: "pos_accounting_period_id" },
        ]
      },
      {
        name: "accounting_period_id_1",
        fields: [
          { name: "pos_accounting_period_id" },
        ]
      },
      {
        name: "fk_pos_budget_pos_level_three_chart_of_accounts_copy_1_1",
        fields: [
          { name: "pos_level_three_chart_of_account_id" },
        ]
      },
      {
        name: "fk_pos_budget_pos_level_three_chart_of_accounts_copy_1_1_1",
        fields: [
          { name: "pos_level_three_chart_of_account_id" },
        ]
      },
    ]
  });
};

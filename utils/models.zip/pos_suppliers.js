const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pos_suppliers', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    pos_hub_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    pos_station_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_stations',
        key: 'id'
      }
    },
    prepayments_subaccount_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_subledger_account_subaccounts',
        key: 'id'
      }
    },
    payable_subaccount_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_subledger_account_subaccounts',
        key: 'id'
      }
    },
    name: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    tel: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    email: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    created: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'pos_suppliers',
    timestamps: false,
    indexes: [
      {
        name: "payable_subacccount_id",
        fields: [
          { name: "payable_subaccount_id" },
        ]
      },
      {
        name: "prepayments_subaccount_id",
        fields: [
          { name: "prepayments_subaccount_id" },
        ]
      },
    ]
  });
};

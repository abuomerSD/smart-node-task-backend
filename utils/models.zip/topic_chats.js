const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('topic_chats', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    topic_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'topics',
        key: 'id'
      }
    },
    chat: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    has_images: {
      type: DataTypes.TINYINT,
      allowNull: false
    },
    source: {
      type: DataTypes.TINYINT,
      allowNull: false
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    created: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'topic_chats',
    timestamps: false,
    indexes: [
      {
        name: "topic_id",
        fields: [
          { name: "topic_id" },
        ]
      },
    ]
  });
};

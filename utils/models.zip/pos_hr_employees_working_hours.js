const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pos_hr_employees_working_hours', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    pos_hr_employee_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_hr_employees',
        key: 'id'
      }
    },
    pos_hr_weekday_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_hr_weekdays',
        key: 'id'
      }
    },
    start_time: {
      type: DataTypes.TIME,
      allowNull: true
    },
    end_time: {
      type: DataTypes.TIME,
      allowNull: true
    },
    created: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'pos_hr_employees_working_hours',
    timestamps: false,
    indexes: [
      {
        name: "fk_pos_hr_employees_working_hours_pos_hr_employees_1",
        fields: [
          { name: "pos_hr_employee_id" },
        ]
      },
      {
        name: "fk_pos_hr_employees_working_hours_pos_hr_weekdays_1",
        fields: [
          { name: "pos_hr_weekday_id" },
        ]
      },
    ]
  });
};

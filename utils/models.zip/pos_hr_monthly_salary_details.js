const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pos_hr_monthly_salary_details', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    pos_hr_monthly_salary_id: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    emp_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_hr_employees',
        key: 'id'
      }
    },
    type: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    salary_item_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_hr_salary_items',
        key: 'id'
      }
    },
    month: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    value: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    year: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    transaction_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    received: {
      type: DataTypes.DATE,
      allowNull: true
    },
    created: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'pos_hr_monthly_salary_details',
    timestamps: false,
    indexes: [
      {
        name: "fk_monthly_salary_details_emps_1",
        fields: [
          { name: "emp_id" },
        ]
      },
      {
        name: "fk_monthly_salary_details_salary_items_1",
        fields: [
          { name: "salary_item_id" },
        ]
      },
      {
        name: "fk_monthly_salary_details_transactions_1",
        fields: [
          { name: "transaction_id" },
        ]
      },
    ]
  });
};

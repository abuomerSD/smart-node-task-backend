const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pos_station_price_list_type', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    pos_stations_price_list_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_stations_price_list',
        key: 'id'
      }
    },
    name: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    discount: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    percentage: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    created: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'pos_station_price_list_type',
    timestamps: false,
    indexes: [
      {
        name: "pos_stations_price_list_id",
        fields: [
          { name: "pos_stations_price_list_id" },
        ]
      },
    ]
  });
};

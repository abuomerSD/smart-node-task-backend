const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pos_budget_transfers', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    from_pos_budget_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_budget',
        key: 'id'
      }
    },
    to_pos_budget_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_budget',
        key: 'id'
      }
    },
    pos_station_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_stations',
        key: 'id'
      }
    },
    value: {
      type: DataTypes.DECIMAL,
      allowNull: false
    },
    pos_user_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_users',
        key: 'id'
      }
    },
    created: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'pos_budget_transfers',
    timestamps: false,
    indexes: [
      {
        name: "from_pos_budget_id_ioo",
        fields: [
          { name: "from_pos_budget_id" },
        ]
      },
      {
        name: "from_pos_budget_id_ioo_1",
        fields: [
          { name: "from_pos_budget_id" },
        ]
      },
      {
        name: "to_pos_budget_id_asd",
        fields: [
          { name: "to_pos_budget_id" },
        ]
      },
      {
        name: "to_pos_budget_id_asd_1",
        fields: [
          { name: "to_pos_budget_id" },
        ]
      },
      {
        name: "user_id_asdf",
        fields: [
          { name: "pos_user_id" },
        ]
      },
      {
        name: "user_id_asdf_1",
        fields: [
          { name: "pos_user_id" },
        ]
      },
    ]
  });
};

var DataTypes = require("sequelize").DataTypes;
var _intermed = require("./intermed");
var _monthly_deduction_details = require("./monthly_deduction_details");
var _pos_accounting_periods = require("./pos_accounting_periods");
var _pos_agents = require("./pos_agents");
var _pos_break_units_logs = require("./pos_break_units_logs");
var _pos_budget = require("./pos_budget");
var _pos_budget_transfers = require("./pos_budget_transfers");
var _pos_cash_accounts = require("./pos_cash_accounts");
var _pos_categories = require("./pos_categories");
var _pos_cheques = require("./pos_cheques");
var _pos_coupon_categories = require("./pos_coupon_categories");
var _pos_coupons = require("./pos_coupons");
var _pos_credit_note_details = require("./pos_credit_note_details");
var _pos_credit_notes = require("./pos_credit_notes");
var _pos_customer_categories = require("./pos_customer_categories");
var _pos_customers = require("./pos_customers");
var _pos_deleted_data = require("./pos_deleted_data");
var _pos_fixed_asset_logs = require("./pos_fixed_asset_logs");
var _pos_fixed_asset_types = require("./pos_fixed_asset_types");
var _pos_fixed_assets = require("./pos_fixed_assets");
var _pos_hr_attendance = require("./pos_hr_attendance");
var _pos_hr_award_types = require("./pos_hr_award_types");
var _pos_hr_awards = require("./pos_hr_awards");
var _pos_hr_complain_types = require("./pos_hr_complain_types");
var _pos_hr_complains = require("./pos_hr_complains");
var _pos_hr_department_kpis = require("./pos_hr_department_kpis");
var _pos_hr_departments = require("./pos_hr_departments");
var _pos_hr_emp_salary_items = require("./pos_hr_emp_salary_items");
var _pos_hr_employee_departments = require("./pos_hr_employee_departments");
var _pos_hr_employee_files = require("./pos_hr_employee_files");
var _pos_hr_employee_kpi_records = require("./pos_hr_employee_kpi_records");
var _pos_hr_employee_transfers = require("./pos_hr_employee_transfers");
var _pos_hr_employee_warnings = require("./pos_hr_employee_warnings");
var _pos_hr_employees = require("./pos_hr_employees");
var _pos_hr_employees_working_hours = require("./pos_hr_employees_working_hours");
var _pos_hr_holiday_departments = require("./pos_hr_holiday_departments");
var _pos_hr_holidays = require("./pos_hr_holidays");
var _pos_hr_job_titles = require("./pos_hr_job_titles");
var _pos_hr_leave_types = require("./pos_hr_leave_types");
var _pos_hr_leaves = require("./pos_hr_leaves");
var _pos_hr_monthly_salaries = require("./pos_hr_monthly_salaries");
var _pos_hr_monthly_salary_details = require("./pos_hr_monthly_salary_details");
var _pos_hr_salary_items = require("./pos_hr_salary_items");
var _pos_hr_tax_levels = require("./pos_hr_tax_levels");
var _pos_hr_weekdays = require("./pos_hr_weekdays");
var _pos_hub_features = require("./pos_hub_features");
var _pos_hub_packages = require("./pos_hub_packages");
var _pos_hub_packages_features = require("./pos_hub_packages_features");
var _pos_hub_subscriptions = require("./pos_hub_subscriptions");
var _pos_hubs = require("./pos_hubs");
var _pos_inventories = require("./pos_inventories");
var _pos_inventory_items = require("./pos_inventory_items");
var _pos_inventory_layers = require("./pos_inventory_layers");
var _pos_inventory_transfer_details = require("./pos_inventory_transfer_details");
var _pos_inventory_transfers = require("./pos_inventory_transfers");
var _pos_job_titles = require("./pos_job_titles");
var _pos_kitchen_products = require("./pos_kitchen_products");
var _pos_kitchens = require("./pos_kitchens");
var _pos_level_one_chart_of_accounts = require("./pos_level_one_chart_of_accounts");
var _pos_level_three_chart_of_accounts = require("./pos_level_three_chart_of_accounts");
var _pos_level_two_chart_of_accounts = require("./pos_level_two_chart_of_accounts");
var _pos_main_chart_of_accounts_types = require("./pos_main_chart_of_accounts_types");
var _pos_order_payments = require("./pos_order_payments");
var _pos_price_list_products = require("./pos_price_list_products");
var _pos_printers = require("./pos_printers");
var _pos_product_additions = require("./pos_product_additions");
var _pos_product_unit_customer_categories = require("./pos_product_unit_customer_categories");
var _pos_product_units = require("./pos_product_units");
var _pos_products = require("./pos_products");
var _pos_purchase_item_types = require("./pos_purchase_item_types");
var _pos_purchase_order_details = require("./pos_purchase_order_details");
var _pos_purchase_orders = require("./pos_purchase_orders");
var _pos_raw_materials_categories = require("./pos_raw_materials_categories");
var _pos_raw_materials_products = require("./pos_raw_materials_products");
var _pos_reconciliation = require("./pos_reconciliation");
var _pos_revenue_categories = require("./pos_revenue_categories");
var _pos_revenue_categorization = require("./pos_revenue_categorization");
var _pos_roles = require("./pos_roles");
var _pos_salary_deduction = require("./pos_salary_deduction");
var _pos_salary_item = require("./pos_salary_item");
var _pos_salary_items_types = require("./pos_salary_items_types");
var _pos_sale_order_detail_additions = require("./pos_sale_order_detail_additions");
var _pos_sale_order_details = require("./pos_sale_order_details");
var _pos_sale_orders = require("./pos_sale_orders");
var _pos_share_holders = require("./pos_share_holders");
var _pos_station_floor_tables = require("./pos_station_floor_tables");
var _pos_station_floors = require("./pos_station_floors");
var _pos_station_floors_shalves = require("./pos_station_floors_shalves");
var _pos_station_price_list_type = require("./pos_station_price_list_type");
var _pos_stations = require("./pos_stations");
var _pos_stations_price_list = require("./pos_stations_price_list");
var _pos_subledger = require("./pos_subledger");
var _pos_subledger_account_subaccounts = require("./pos_subledger_account_subaccounts");
var _pos_subledger_accounts = require("./pos_subledger_accounts");
var _pos_subledger_parent_accounts = require("./pos_subledger_parent_accounts");
var _pos_subledger_transactions = require("./pos_subledger_transactions");
var _pos_subscriptions = require("./pos_subscriptions");
var _pos_suppliers = require("./pos_suppliers");
var _pos_transaction_details = require("./pos_transaction_details");
var _pos_transactions = require("./pos_transactions");
var _pos_types = require("./pos_types");
var _pos_user_roles = require("./pos_user_roles");
var _pos_users = require("./pos_users");
var _subscription_features = require("./subscription_features");
var _subscription_packages = require("./subscription_packages");
var _subscription_packages_features = require("./subscription_packages_features");
var _tables_sync = require("./tables_sync");
var _topic_chats = require("./topic_chats");
var _topics = require("./topics");

function initModels(sequelize) {
  var intermed = _intermed(sequelize, DataTypes);
  var monthly_deduction_details = _monthly_deduction_details(sequelize, DataTypes);
  var pos_accounting_periods = _pos_accounting_periods(sequelize, DataTypes);
  var pos_agents = _pos_agents(sequelize, DataTypes);
  var pos_break_units_logs = _pos_break_units_logs(sequelize, DataTypes);
  var pos_budget = _pos_budget(sequelize, DataTypes);
  var pos_budget_transfers = _pos_budget_transfers(sequelize, DataTypes);
  var pos_cash_accounts = _pos_cash_accounts(sequelize, DataTypes);
  var pos_categories = _pos_categories(sequelize, DataTypes);
  var pos_cheques = _pos_cheques(sequelize, DataTypes);
  var pos_coupon_categories = _pos_coupon_categories(sequelize, DataTypes);
  var pos_coupons = _pos_coupons(sequelize, DataTypes);
  var pos_credit_note_details = _pos_credit_note_details(sequelize, DataTypes);
  var pos_credit_notes = _pos_credit_notes(sequelize, DataTypes);
  var pos_customer_categories = _pos_customer_categories(sequelize, DataTypes);
  var pos_customers = _pos_customers(sequelize, DataTypes);
  var pos_deleted_data = _pos_deleted_data(sequelize, DataTypes);
  var pos_fixed_asset_logs = _pos_fixed_asset_logs(sequelize, DataTypes);
  var pos_fixed_asset_types = _pos_fixed_asset_types(sequelize, DataTypes);
  var pos_fixed_assets = _pos_fixed_assets(sequelize, DataTypes);
  var pos_hr_attendance = _pos_hr_attendance(sequelize, DataTypes);
  var pos_hr_award_types = _pos_hr_award_types(sequelize, DataTypes);
  var pos_hr_awards = _pos_hr_awards(sequelize, DataTypes);
  var pos_hr_complain_types = _pos_hr_complain_types(sequelize, DataTypes);
  var pos_hr_complains = _pos_hr_complains(sequelize, DataTypes);
  var pos_hr_department_kpis = _pos_hr_department_kpis(sequelize, DataTypes);
  var pos_hr_departments = _pos_hr_departments(sequelize, DataTypes);
  var pos_hr_emp_salary_items = _pos_hr_emp_salary_items(sequelize, DataTypes);
  var pos_hr_employee_departments = _pos_hr_employee_departments(sequelize, DataTypes);
  var pos_hr_employee_files = _pos_hr_employee_files(sequelize, DataTypes);
  var pos_hr_employee_kpi_records = _pos_hr_employee_kpi_records(sequelize, DataTypes);
  var pos_hr_employee_transfers = _pos_hr_employee_transfers(sequelize, DataTypes);
  var pos_hr_employee_warnings = _pos_hr_employee_warnings(sequelize, DataTypes);
  var pos_hr_employees = _pos_hr_employees(sequelize, DataTypes);
  var pos_hr_employees_working_hours = _pos_hr_employees_working_hours(sequelize, DataTypes);
  var pos_hr_holiday_departments = _pos_hr_holiday_departments(sequelize, DataTypes);
  var pos_hr_holidays = _pos_hr_holidays(sequelize, DataTypes);
  var pos_hr_job_titles = _pos_hr_job_titles(sequelize, DataTypes);
  var pos_hr_leave_types = _pos_hr_leave_types(sequelize, DataTypes);
  var pos_hr_leaves = _pos_hr_leaves(sequelize, DataTypes);
  var pos_hr_monthly_salaries = _pos_hr_monthly_salaries(sequelize, DataTypes);
  var pos_hr_monthly_salary_details = _pos_hr_monthly_salary_details(sequelize, DataTypes);
  var pos_hr_salary_items = _pos_hr_salary_items(sequelize, DataTypes);
  var pos_hr_tax_levels = _pos_hr_tax_levels(sequelize, DataTypes);
  var pos_hr_weekdays = _pos_hr_weekdays(sequelize, DataTypes);
  var pos_hub_features = _pos_hub_features(sequelize, DataTypes);
  var pos_hub_packages = _pos_hub_packages(sequelize, DataTypes);
  var pos_hub_packages_features = _pos_hub_packages_features(sequelize, DataTypes);
  var pos_hub_subscriptions = _pos_hub_subscriptions(sequelize, DataTypes);
  var pos_hubs = _pos_hubs(sequelize, DataTypes);
  var pos_inventories = _pos_inventories(sequelize, DataTypes);
  var pos_inventory_items = _pos_inventory_items(sequelize, DataTypes);
  var pos_inventory_layers = _pos_inventory_layers(sequelize, DataTypes);
  var pos_inventory_transfer_details = _pos_inventory_transfer_details(sequelize, DataTypes);
  var pos_inventory_transfers = _pos_inventory_transfers(sequelize, DataTypes);
  var pos_job_titles = _pos_job_titles(sequelize, DataTypes);
  var pos_kitchen_products = _pos_kitchen_products(sequelize, DataTypes);
  var pos_kitchens = _pos_kitchens(sequelize, DataTypes);
  var pos_level_one_chart_of_accounts = _pos_level_one_chart_of_accounts(sequelize, DataTypes);
  var pos_level_three_chart_of_accounts = _pos_level_three_chart_of_accounts(sequelize, DataTypes);
  var pos_level_two_chart_of_accounts = _pos_level_two_chart_of_accounts(sequelize, DataTypes);
  var pos_main_chart_of_accounts_types = _pos_main_chart_of_accounts_types(sequelize, DataTypes);
  var pos_order_payments = _pos_order_payments(sequelize, DataTypes);
  var pos_price_list_products = _pos_price_list_products(sequelize, DataTypes);
  var pos_printers = _pos_printers(sequelize, DataTypes);
  var pos_product_additions = _pos_product_additions(sequelize, DataTypes);
  var pos_product_unit_customer_categories = _pos_product_unit_customer_categories(sequelize, DataTypes);
  var pos_product_units = _pos_product_units(sequelize, DataTypes);
  var pos_products = _pos_products(sequelize, DataTypes);
  var pos_purchase_item_types = _pos_purchase_item_types(sequelize, DataTypes);
  var pos_purchase_order_details = _pos_purchase_order_details(sequelize, DataTypes);
  var pos_purchase_orders = _pos_purchase_orders(sequelize, DataTypes);
  var pos_raw_materials_categories = _pos_raw_materials_categories(sequelize, DataTypes);
  var pos_raw_materials_products = _pos_raw_materials_products(sequelize, DataTypes);
  var pos_reconciliation = _pos_reconciliation(sequelize, DataTypes);
  var pos_revenue_categories = _pos_revenue_categories(sequelize, DataTypes);
  var pos_revenue_categorization = _pos_revenue_categorization(sequelize, DataTypes);
  var pos_roles = _pos_roles(sequelize, DataTypes);
  var pos_salary_deduction = _pos_salary_deduction(sequelize, DataTypes);
  var pos_salary_item = _pos_salary_item(sequelize, DataTypes);
  var pos_salary_items_types = _pos_salary_items_types(sequelize, DataTypes);
  var pos_sale_order_detail_additions = _pos_sale_order_detail_additions(sequelize, DataTypes);
  var pos_sale_order_details = _pos_sale_order_details(sequelize, DataTypes);
  var pos_sale_orders = _pos_sale_orders(sequelize, DataTypes);
  var pos_share_holders = _pos_share_holders(sequelize, DataTypes);
  var pos_station_floor_tables = _pos_station_floor_tables(sequelize, DataTypes);
  var pos_station_floors = _pos_station_floors(sequelize, DataTypes);
  var pos_station_floors_shalves = _pos_station_floors_shalves(sequelize, DataTypes);
  var pos_station_price_list_type = _pos_station_price_list_type(sequelize, DataTypes);
  var pos_stations = _pos_stations(sequelize, DataTypes);
  var pos_stations_price_list = _pos_stations_price_list(sequelize, DataTypes);
  var pos_subledger = _pos_subledger(sequelize, DataTypes);
  var pos_subledger_account_subaccounts = _pos_subledger_account_subaccounts(sequelize, DataTypes);
  var pos_subledger_accounts = _pos_subledger_accounts(sequelize, DataTypes);
  var pos_subledger_parent_accounts = _pos_subledger_parent_accounts(sequelize, DataTypes);
  var pos_subledger_transactions = _pos_subledger_transactions(sequelize, DataTypes);
  var pos_subscriptions = _pos_subscriptions(sequelize, DataTypes);
  var pos_suppliers = _pos_suppliers(sequelize, DataTypes);
  var pos_transaction_details = _pos_transaction_details(sequelize, DataTypes);
  var pos_transactions = _pos_transactions(sequelize, DataTypes);
  var pos_types = _pos_types(sequelize, DataTypes);
  var pos_user_roles = _pos_user_roles(sequelize, DataTypes);
  var pos_users = _pos_users(sequelize, DataTypes);
  var subscription_features = _subscription_features(sequelize, DataTypes);
  var subscription_packages = _subscription_packages(sequelize, DataTypes);
  var subscription_packages_features = _subscription_packages_features(sequelize, DataTypes);
  var tables_sync = _tables_sync(sequelize, DataTypes);
  var topic_chats = _topic_chats(sequelize, DataTypes);
  var topics = _topics(sequelize, DataTypes);

  pos_budget.belongsTo(pos_accounting_periods, { as: "pos_accounting_period", foreignKey: "pos_accounting_period_id"});
  pos_accounting_periods.hasMany(pos_budget, { as: "pos_budgets", foreignKey: "pos_accounting_period_id"});
  pos_transactions.belongsTo(pos_accounting_periods, { as: "pos_accounting_period", foreignKey: "pos_accounting_period_id"});
  pos_accounting_periods.hasMany(pos_transactions, { as: "pos_transactions", foreignKey: "pos_accounting_period_id"});
  pos_budget_transfers.belongsTo(pos_budget, { as: "to_pos_budget", foreignKey: "to_pos_budget_id"});
  pos_budget.hasMany(pos_budget_transfers, { as: "pos_budget_transfers", foreignKey: "to_pos_budget_id"});
  pos_budget_transfers.belongsTo(pos_budget, { as: "from_pos_budget", foreignKey: "from_pos_budget_id"});
  pos_budget.hasMany(pos_budget_transfers, { as: "from_pos_budget_pos_budget_transfers", foreignKey: "from_pos_budget_id"});
  pos_hr_employees.belongsTo(pos_cash_accounts, { as: "pos_cash_account", foreignKey: "pos_cash_account_id"});
  pos_cash_accounts.hasMany(pos_hr_employees, { as: "pos_hr_employees", foreignKey: "pos_cash_account_id"});
  pos_order_payments.belongsTo(pos_cash_accounts, { as: "pos_cash_account", foreignKey: "pos_cash_account_id"});
  pos_cash_accounts.hasMany(pos_order_payments, { as: "pos_order_payments", foreignKey: "pos_cash_account_id"});
  pos_users.belongsTo(pos_cash_accounts, { as: "pos_cash_cash_account", foreignKey: "pos_cash_cash_account_id"});
  pos_cash_accounts.hasMany(pos_users, { as: "pos_users", foreignKey: "pos_cash_cash_account_id"});
  pos_users.belongsTo(pos_cash_accounts, { as: "pos_bank_cash_account", foreignKey: "pos_bank_cash_account_id"});
  pos_cash_accounts.hasMany(pos_users, { as: "pos_bank_cash_account_pos_users", foreignKey: "pos_bank_cash_account_id"});
  pos_products.belongsTo(pos_categories, { as: "pos_category", foreignKey: "pos_category_id"});
  pos_categories.hasMany(pos_products, { as: "pos_products", foreignKey: "pos_category_id"});
  pos_coupons.belongsTo(pos_coupon_categories, { as: "pos_coupon_category", foreignKey: "pos_coupon_category_id"});
  pos_coupon_categories.hasMany(pos_coupons, { as: "pos_coupons", foreignKey: "pos_coupon_category_id"});
  pos_sale_orders.belongsTo(pos_coupons, { as: "pos_coupon", foreignKey: "pos_coupon_id"});
  pos_coupons.hasMany(pos_sale_orders, { as: "pos_sale_orders", foreignKey: "pos_coupon_id"});
  pos_credit_note_details.belongsTo(pos_credit_notes, { as: "pos_credit_note", foreignKey: "pos_credit_note_id"});
  pos_credit_notes.hasMany(pos_credit_note_details, { as: "pos_credit_note_details", foreignKey: "pos_credit_note_id"});
  pos_customers.belongsTo(pos_customer_categories, { as: "pos_customer_category", foreignKey: "pos_customer_category_id"});
  pos_customer_categories.hasMany(pos_customers, { as: "pos_customers", foreignKey: "pos_customer_category_id"});
  pos_product_unit_customer_categories.belongsTo(pos_customer_categories, { as: "pos_customer_category", foreignKey: "pos_customer_category_id"});
  pos_customer_categories.hasMany(pos_product_unit_customer_categories, { as: "pos_product_unit_customer_categories", foreignKey: "pos_customer_category_id"});
  pos_sale_orders.belongsTo(pos_customers, { as: "custmor", foreignKey: "custmor_id"});
  pos_customers.hasMany(pos_sale_orders, { as: "pos_sale_orders", foreignKey: "custmor_id"});
  pos_fixed_assets.belongsTo(pos_fixed_asset_types, { as: "pos_fixed_asset_type", foreignKey: "pos_fixed_asset_type_id"});
  pos_fixed_asset_types.hasMany(pos_fixed_assets, { as: "pos_fixed_assets", foreignKey: "pos_fixed_asset_type_id"});
  pos_fixed_asset_logs.belongsTo(pos_fixed_assets, { as: "asset", foreignKey: "asset_id"});
  pos_fixed_assets.hasMany(pos_fixed_asset_logs, { as: "pos_fixed_asset_logs", foreignKey: "asset_id"});
  pos_hr_awards.belongsTo(pos_hr_award_types, { as: "pos_hr_award_type", foreignKey: "pos_hr_award_type_id"});
  pos_hr_award_types.hasMany(pos_hr_awards, { as: "pos_hr_awards", foreignKey: "pos_hr_award_type_id"});
  pos_hr_complains.belongsTo(pos_hr_complain_types, { as: "pos_hr_complain_type", foreignKey: "pos_hr_complain_type_id"});
  pos_hr_complain_types.hasMany(pos_hr_complains, { as: "pos_hr_complains", foreignKey: "pos_hr_complain_type_id"});
  pos_hr_employee_kpi_records.belongsTo(pos_hr_department_kpis, { as: "pos_hr_department_kpi", foreignKey: "pos_hr_department_kpi_id"});
  pos_hr_department_kpis.hasMany(pos_hr_employee_kpi_records, { as: "pos_hr_employee_kpi_records", foreignKey: "pos_hr_department_kpi_id"});
  pos_hr_department_kpis.belongsTo(pos_hr_departments, { as: "pos_hr_department", foreignKey: "pos_hr_department_id"});
  pos_hr_departments.hasMany(pos_hr_department_kpis, { as: "pos_hr_department_kpis", foreignKey: "pos_hr_department_id"});
  pos_hr_employee_departments.belongsTo(pos_hr_departments, { as: "pos_hr_department", foreignKey: "pos_hr_department_id"});
  pos_hr_departments.hasMany(pos_hr_employee_departments, { as: "pos_hr_employee_departments", foreignKey: "pos_hr_department_id"});
  pos_hr_employee_transfers.belongsTo(pos_hr_departments, { as: "to_pos_hr_department", foreignKey: "to_pos_hr_department_id"});
  pos_hr_departments.hasMany(pos_hr_employee_transfers, { as: "pos_hr_employee_transfers", foreignKey: "to_pos_hr_department_id"});
  pos_hr_employee_transfers.belongsTo(pos_hr_departments, { as: "from_pos_hr_department", foreignKey: "from_pos_hr_department_id"});
  pos_hr_departments.hasMany(pos_hr_employee_transfers, { as: "from_pos_hr_department_pos_hr_employee_transfers", foreignKey: "from_pos_hr_department_id"});
  pos_hr_employees.belongsTo(pos_hr_departments, { as: "pos_hr_department", foreignKey: "pos_hr_department_id"});
  pos_hr_departments.hasMany(pos_hr_employees, { as: "pos_hr_employees", foreignKey: "pos_hr_department_id"});
  pos_hr_holiday_departments.belongsTo(pos_hr_departments, { as: "pos_hr_department", foreignKey: "pos_hr_department_id"});
  pos_hr_departments.hasMany(pos_hr_holiday_departments, { as: "pos_hr_holiday_departments", foreignKey: "pos_hr_department_id"});
  monthly_deduction_details.belongsTo(pos_hr_employees, { as: "emp", foreignKey: "emp_id"});
  pos_hr_employees.hasMany(monthly_deduction_details, { as: "monthly_deduction_details", foreignKey: "emp_id"});
  pos_hr_attendance.belongsTo(pos_hr_employees, { as: "pos_hr_employee", foreignKey: "pos_hr_employee_id"});
  pos_hr_employees.hasMany(pos_hr_attendance, { as: "pos_hr_attendances", foreignKey: "pos_hr_employee_id"});
  pos_hr_awards.belongsTo(pos_hr_employees, { as: "pos_hr_employee", foreignKey: "pos_hr_employee_id"});
  pos_hr_employees.hasMany(pos_hr_awards, { as: "pos_hr_awards", foreignKey: "pos_hr_employee_id"});
  pos_hr_complains.belongsTo(pos_hr_employees, { as: "pos_hr_employee", foreignKey: "pos_hr_employee_id"});
  pos_hr_employees.hasMany(pos_hr_complains, { as: "pos_hr_complains", foreignKey: "pos_hr_employee_id"});
  pos_hr_emp_salary_items.belongsTo(pos_hr_employees, { as: "pos_hr_emp", foreignKey: "pos_hr_emp_id"});
  pos_hr_employees.hasMany(pos_hr_emp_salary_items, { as: "pos_hr_emp_salary_items", foreignKey: "pos_hr_emp_id"});
  pos_hr_employee_departments.belongsTo(pos_hr_employees, { as: "pos_hr_employee", foreignKey: "pos_hr_employee_id"});
  pos_hr_employees.hasMany(pos_hr_employee_departments, { as: "pos_hr_employee_departments", foreignKey: "pos_hr_employee_id"});
  pos_hr_employee_files.belongsTo(pos_hr_employees, { as: "pos_hr_employee", foreignKey: "pos_hr_employee_id"});
  pos_hr_employees.hasMany(pos_hr_employee_files, { as: "pos_hr_employee_files", foreignKey: "pos_hr_employee_id"});
  pos_hr_employee_kpi_records.belongsTo(pos_hr_employees, { as: "pos_hr_employee", foreignKey: "pos_hr_employee_id"});
  pos_hr_employees.hasMany(pos_hr_employee_kpi_records, { as: "pos_hr_employee_kpi_records", foreignKey: "pos_hr_employee_id"});
  pos_hr_employee_transfers.belongsTo(pos_hr_employees, { as: "pos_hr_employee", foreignKey: "pos_hr_employee_id"});
  pos_hr_employees.hasMany(pos_hr_employee_transfers, { as: "pos_hr_employee_transfers", foreignKey: "pos_hr_employee_id"});
  pos_hr_employee_warnings.belongsTo(pos_hr_employees, { as: "pos_hr_employee", foreignKey: "pos_hr_employee_id"});
  pos_hr_employees.hasMany(pos_hr_employee_warnings, { as: "pos_hr_employee_warnings", foreignKey: "pos_hr_employee_id"});
  pos_hr_employees_working_hours.belongsTo(pos_hr_employees, { as: "pos_hr_employee", foreignKey: "pos_hr_employee_id"});
  pos_hr_employees.hasMany(pos_hr_employees_working_hours, { as: "pos_hr_employees_working_hours", foreignKey: "pos_hr_employee_id"});
  pos_hr_leaves.belongsTo(pos_hr_employees, { as: "pos_hr_employee", foreignKey: "pos_hr_employee_id"});
  pos_hr_employees.hasMany(pos_hr_leaves, { as: "pos_hr_leaves", foreignKey: "pos_hr_employee_id"});
  pos_hr_monthly_salaries.belongsTo(pos_hr_employees, { as: "emp", foreignKey: "emp_id"});
  pos_hr_employees.hasMany(pos_hr_monthly_salaries, { as: "pos_hr_monthly_salaries", foreignKey: "emp_id"});
  pos_hr_monthly_salary_details.belongsTo(pos_hr_employees, { as: "emp", foreignKey: "emp_id"});
  pos_hr_employees.hasMany(pos_hr_monthly_salary_details, { as: "pos_hr_monthly_salary_details", foreignKey: "emp_id"});
  pos_hr_holiday_departments.belongsTo(pos_hr_holidays, { as: "pos_hr_hoilday", foreignKey: "pos_hr_hoilday_id"});
  pos_hr_holidays.hasMany(pos_hr_holiday_departments, { as: "pos_hr_holiday_departments", foreignKey: "pos_hr_hoilday_id"});
  pos_hr_employee_departments.belongsTo(pos_hr_job_titles, { as: "pos_hr_job_title", foreignKey: "pos_hr_job_title_id"});
  pos_hr_job_titles.hasMany(pos_hr_employee_departments, { as: "pos_hr_employee_departments", foreignKey: "pos_hr_job_title_id"});
  pos_hr_leaves.belongsTo(pos_hr_leave_types, { as: "pos_hr_leave_type", foreignKey: "pos_hr_leave_type_id"});
  pos_hr_leave_types.hasMany(pos_hr_leaves, { as: "pos_hr_leaves", foreignKey: "pos_hr_leave_type_id"});
  pos_hr_emp_salary_items.belongsTo(pos_hr_salary_items, { as: "pos_hr_salary_item", foreignKey: "pos_hr_salary_item_id"});
  pos_hr_salary_items.hasMany(pos_hr_emp_salary_items, { as: "pos_hr_emp_salary_items", foreignKey: "pos_hr_salary_item_id"});
  pos_hr_monthly_salary_details.belongsTo(pos_hr_salary_items, { as: "salary_item", foreignKey: "salary_item_id"});
  pos_hr_salary_items.hasMany(pos_hr_monthly_salary_details, { as: "pos_hr_monthly_salary_details", foreignKey: "salary_item_id"});
  pos_hr_employees_working_hours.belongsTo(pos_hr_weekdays, { as: "pos_hr_weekday", foreignKey: "pos_hr_weekday_id"});
  pos_hr_weekdays.hasMany(pos_hr_employees_working_hours, { as: "pos_hr_employees_working_hours", foreignKey: "pos_hr_weekday_id"});
  pos_hub_packages_features.belongsTo(pos_hub_features, { as: "pos_hub_feature", foreignKey: "pos_hub_feature_id"});
  pos_hub_features.hasMany(pos_hub_packages_features, { as: "pos_hub_packages_features", foreignKey: "pos_hub_feature_id"});
  pos_hub_packages_features.belongsTo(pos_hub_packages, { as: "pos_hub_package", foreignKey: "pos_hub_package_id"});
  pos_hub_packages.hasMany(pos_hub_packages_features, { as: "pos_hub_packages_features", foreignKey: "pos_hub_package_id"});
  pos_hub_subscriptions.belongsTo(pos_hub_packages, { as: "pos_hub_packge", foreignKey: "pos_hub_packge_id"});
  pos_hub_packages.hasMany(pos_hub_subscriptions, { as: "pos_hub_subscriptions", foreignKey: "pos_hub_packge_id"});
  pos_hub_subscriptions.belongsTo(pos_hub_subscriptions, { as: "upgrade_from_pos_hub_subscription", foreignKey: "upgrade_from_pos_hub_subscription_id"});
  pos_hub_subscriptions.hasMany(pos_hub_subscriptions, { as: "pos_hub_subscriptions", foreignKey: "upgrade_from_pos_hub_subscription_id"});
  pos_categories.belongsTo(pos_hubs, { as: "pos_hub", foreignKey: "pos_hub_id"});
  pos_hubs.hasMany(pos_categories, { as: "pos_categories", foreignKey: "pos_hub_id"});
  pos_hub_subscriptions.belongsTo(pos_hubs, { as: "pos_hub", foreignKey: "pos_hub_id"});
  pos_hubs.hasMany(pos_hub_subscriptions, { as: "pos_hub_subscriptions", foreignKey: "pos_hub_id"});
  pos_raw_materials_categories.belongsTo(pos_hubs, { as: "pos_hub", foreignKey: "pos_hub_id"});
  pos_hubs.hasMany(pos_raw_materials_categories, { as: "pos_raw_materials_categories", foreignKey: "pos_hub_id"});
  pos_revenue_categories.belongsTo(pos_hubs, { as: "pos_hub", foreignKey: "pos_hub_id"});
  pos_hubs.hasMany(pos_revenue_categories, { as: "pos_revenue_categories", foreignKey: "pos_hub_id"});
  pos_salary_item.belongsTo(pos_hubs, { as: "pos_hub", foreignKey: "pos_hub_id"});
  pos_hubs.hasMany(pos_salary_item, { as: "pos_salary_items", foreignKey: "pos_hub_id"});
  pos_share_holders.belongsTo(pos_hubs, { as: "pos_hub", foreignKey: "pos_hub_id"});
  pos_hubs.hasMany(pos_share_holders, { as: "pos_share_holders", foreignKey: "pos_hub_id"});
  pos_stations.belongsTo(pos_hubs, { as: "pos_hub", foreignKey: "pos_hub_id"});
  pos_hubs.hasMany(pos_stations, { as: "pos_stations", foreignKey: "pos_hub_id"});
  pos_break_units_logs.belongsTo(pos_inventories, { as: "pos_inventory", foreignKey: "pos_inventory_id"});
  pos_inventories.hasMany(pos_break_units_logs, { as: "pos_break_units_logs", foreignKey: "pos_inventory_id"});
  pos_inventory_items.belongsTo(pos_inventories, { as: "inventory", foreignKey: "inventory_id"});
  pos_inventories.hasMany(pos_inventory_items, { as: "pos_inventory_items", foreignKey: "inventory_id"});
  pos_inventory_transfers.belongsTo(pos_inventories, { as: "to_inventory", foreignKey: "to_inventory_id"});
  pos_inventories.hasMany(pos_inventory_transfers, { as: "pos_inventory_transfers", foreignKey: "to_inventory_id"});
  pos_inventory_transfers.belongsTo(pos_inventories, { as: "from_inventory", foreignKey: "from_inventory_id"});
  pos_inventories.hasMany(pos_inventory_transfers, { as: "from_inventory_pos_inventory_transfers", foreignKey: "from_inventory_id"});
  pos_purchase_orders.belongsTo(pos_inventories, { as: "pos_inventory", foreignKey: "pos_inventory_id"});
  pos_inventories.hasMany(pos_purchase_orders, { as: "pos_purchase_orders", foreignKey: "pos_inventory_id"});
  pos_inventory_layers.belongsTo(pos_inventory_items, { as: "pos_inventory_item", foreignKey: "pos_inventory_item_id"});
  pos_inventory_items.hasMany(pos_inventory_layers, { as: "pos_inventory_layers", foreignKey: "pos_inventory_item_id"});
  pos_inventory_transfer_details.belongsTo(pos_inventory_transfers, { as: "pos_inventory_transfer", foreignKey: "pos_inventory_transfer_id"});
  pos_inventory_transfers.hasMany(pos_inventory_transfer_details, { as: "pos_inventory_transfer_details", foreignKey: "pos_inventory_transfer_id"});
  pos_inventories.belongsTo(pos_kitchens, { as: "pos_kitchen", foreignKey: "pos_kitchen_id"});
  pos_kitchens.hasMany(pos_inventories, { as: "pos_inventories", foreignKey: "pos_kitchen_id"});
  pos_kitchen_products.belongsTo(pos_kitchens, { as: "pos_kitchen", foreignKey: "pos_kitchen_id"});
  pos_kitchens.hasMany(pos_kitchen_products, { as: "pos_kitchen_products", foreignKey: "pos_kitchen_id"});
  pos_level_two_chart_of_accounts.belongsTo(pos_level_one_chart_of_accounts, { as: "pos_level_one_chart_of_account", foreignKey: "pos_level_one_chart_of_account_id"});
  pos_level_one_chart_of_accounts.hasMany(pos_level_two_chart_of_accounts, { as: "pos_level_two_chart_of_accounts", foreignKey: "pos_level_one_chart_of_account_id"});
  pos_budget.belongsTo(pos_level_three_chart_of_accounts, { as: "pos_level_three_chart_of_account", foreignKey: "pos_level_three_chart_of_account_id"});
  pos_level_three_chart_of_accounts.hasMany(pos_budget, { as: "pos_budgets", foreignKey: "pos_level_three_chart_of_account_id"});
  pos_cash_accounts.belongsTo(pos_level_three_chart_of_accounts, { as: "pos_level_three_chart_of_account", foreignKey: "pos_level_three_chart_of_account_id"});
  pos_level_three_chart_of_accounts.hasMany(pos_cash_accounts, { as: "pos_cash_accounts", foreignKey: "pos_level_three_chart_of_account_id"});
  pos_fixed_asset_types.belongsTo(pos_level_three_chart_of_accounts, { as: "pos_level_three_chart_of_account", foreignKey: "pos_level_three_chart_of_account_id"});
  pos_level_three_chart_of_accounts.hasMany(pos_fixed_asset_types, { as: "pos_fixed_asset_types", foreignKey: "pos_level_three_chart_of_account_id"});
  pos_fixed_asset_types.belongsTo(pos_level_three_chart_of_accounts, { as: "ad_pos_level_three_chart_of_account", foreignKey: "ad_pos_level_three_chart_of_account_id"});
  pos_level_three_chart_of_accounts.hasMany(pos_fixed_asset_types, { as: "ad_pos_level_three_chart_of_account_pos_fixed_asset_types", foreignKey: "ad_pos_level_three_chart_of_account_id"});
  pos_subledger_account_subaccounts.belongsTo(pos_level_three_chart_of_accounts, { as: "pos_level_three_chart_of_account", foreignKey: "pos_level_three_chart_of_account_id"});
  pos_level_three_chart_of_accounts.hasMany(pos_subledger_account_subaccounts, { as: "pos_subledger_account_subaccounts", foreignKey: "pos_level_three_chart_of_account_id"});
  pos_transaction_details.belongsTo(pos_level_three_chart_of_accounts, { as: "account", foreignKey: "account_id"});
  pos_level_three_chart_of_accounts.hasMany(pos_transaction_details, { as: "pos_transaction_details", foreignKey: "account_id"});
  pos_level_three_chart_of_accounts.belongsTo(pos_level_two_chart_of_accounts, { as: "pos_level_two_chart_of_account", foreignKey: "pos_level_two_chart_of_account_id"});
  pos_level_two_chart_of_accounts.hasMany(pos_level_three_chart_of_accounts, { as: "pos_level_three_chart_of_accounts", foreignKey: "pos_level_two_chart_of_account_id"});
  pos_subledger_parent_accounts.belongsTo(pos_level_two_chart_of_accounts, { as: "pos_level_two_chart_of_account", foreignKey: "pos_level_two_chart_of_account_id"});
  pos_level_two_chart_of_accounts.hasMany(pos_subledger_parent_accounts, { as: "pos_subledger_parent_accounts", foreignKey: "pos_level_two_chart_of_account_id"});
  pos_level_one_chart_of_accounts.belongsTo(pos_main_chart_of_accounts_types, { as: "pos_main_chart_of_accounts_type", foreignKey: "pos_main_chart_of_accounts_type_id"});
  pos_main_chart_of_accounts_types.hasMany(pos_level_one_chart_of_accounts, { as: "pos_level_one_chart_of_accounts", foreignKey: "pos_main_chart_of_accounts_type_id"});
  pos_kitchens.belongsTo(pos_printers, { as: "pos_printer", foreignKey: "pos_printer_id"});
  pos_printers.hasMany(pos_kitchens, { as: "pos_kitchens", foreignKey: "pos_printer_id"});
  pos_users.belongsTo(pos_printers, { as: "pos_printer", foreignKey: "pos_printer_id"});
  pos_printers.hasMany(pos_users, { as: "pos_users", foreignKey: "pos_printer_id"});
  pos_sale_order_detail_additions.belongsTo(pos_product_additions, { as: "pos_product_addition", foreignKey: "pos_product_addition_id"});
  pos_product_additions.hasMany(pos_sale_order_detail_additions, { as: "pos_sale_order_detail_additions", foreignKey: "pos_product_addition_id"});
  pos_break_units_logs.belongsTo(pos_product_units, { as: "to_unit", foreignKey: "to_unit_id"});
  pos_product_units.hasMany(pos_break_units_logs, { as: "pos_break_units_logs", foreignKey: "to_unit_id"});
  pos_break_units_logs.belongsTo(pos_product_units, { as: "from_unit", foreignKey: "from_unit_id"});
  pos_product_units.hasMany(pos_break_units_logs, { as: "from_unit_pos_break_units_logs", foreignKey: "from_unit_id"});
  pos_inventory_items.belongsTo(pos_product_units, { as: "pos_product_unit", foreignKey: "pos_product_unit_id"});
  pos_product_units.hasMany(pos_inventory_items, { as: "pos_inventory_items", foreignKey: "pos_product_unit_id"});
  pos_inventory_transfer_details.belongsTo(pos_product_units, { as: "pos_product_unit", foreignKey: "pos_product_unit_id"});
  pos_product_units.hasMany(pos_inventory_transfer_details, { as: "pos_inventory_transfer_details", foreignKey: "pos_product_unit_id"});
  pos_product_unit_customer_categories.belongsTo(pos_product_units, { as: "pos_product_unit", foreignKey: "pos_product_unit_id"});
  pos_product_units.hasMany(pos_product_unit_customer_categories, { as: "pos_product_unit_customer_categories", foreignKey: "pos_product_unit_id"});
  pos_purchase_order_details.belongsTo(pos_product_units, { as: "pos_product_unit", foreignKey: "pos_product_unit_id"});
  pos_product_units.hasMany(pos_purchase_order_details, { as: "pos_purchase_order_details", foreignKey: "pos_product_unit_id"});
  pos_sale_order_details.belongsTo(pos_product_units, { as: "pos_product_unit", foreignKey: "pos_product_unit_id"});
  pos_product_units.hasMany(pos_sale_order_details, { as: "pos_sale_order_details", foreignKey: "pos_product_unit_id"});
  pos_kitchen_products.belongsTo(pos_products, { as: "pos_product", foreignKey: "pos_product_id"});
  pos_products.hasMany(pos_kitchen_products, { as: "pos_kitchen_products", foreignKey: "pos_product_id"});
  pos_price_list_products.belongsTo(pos_products, { as: "product", foreignKey: "product_id"});
  pos_products.hasMany(pos_price_list_products, { as: "pos_price_list_products", foreignKey: "product_id"});
  pos_product_additions.belongsTo(pos_products, { as: "pos_product", foreignKey: "pos_product_id"});
  pos_products.hasMany(pos_product_additions, { as: "pos_product_additions", foreignKey: "pos_product_id"});
  pos_product_units.belongsTo(pos_products, { as: "product", foreignKey: "product_id"});
  pos_products.hasMany(pos_product_units, { as: "pos_product_units", foreignKey: "product_id"});
  pos_sale_order_details.belongsTo(pos_products, { as: "product", foreignKey: "product_id"});
  pos_products.hasMany(pos_sale_order_details, { as: "pos_sale_order_details", foreignKey: "product_id"});
  pos_purchase_orders.belongsTo(pos_purchase_item_types, { as: "pos_purchase_item_type", foreignKey: "pos_purchase_item_type_id"});
  pos_purchase_item_types.hasMany(pos_purchase_orders, { as: "pos_purchase_orders", foreignKey: "pos_purchase_item_type_id"});
  pos_purchase_order_details.belongsTo(pos_purchase_orders, { as: "purchase_order", foreignKey: "purchase_order_id"});
  pos_purchase_orders.hasMany(pos_purchase_order_details, { as: "pos_purchase_order_details", foreignKey: "purchase_order_id"});
  pos_raw_materials_products.belongsTo(pos_raw_materials_categories, { as: "pos_raw_materials_category", foreignKey: "pos_raw_materials_category_id"});
  pos_raw_materials_categories.hasMany(pos_raw_materials_products, { as: "pos_raw_materials_products", foreignKey: "pos_raw_materials_category_id"});
  pos_inventory_items.belongsTo(pos_raw_materials_products, { as: "pos_raw_materials_product", foreignKey: "pos_raw_materials_product_id"});
  pos_raw_materials_products.hasMany(pos_inventory_items, { as: "pos_inventory_items", foreignKey: "pos_raw_materials_product_id"});
  pos_inventory_transfer_details.belongsTo(pos_raw_materials_products, { as: "pos_raw_materials_product", foreignKey: "pos_raw_materials_product_id"});
  pos_raw_materials_products.hasMany(pos_inventory_transfer_details, { as: "pos_inventory_transfer_details", foreignKey: "pos_raw_materials_product_id"});
  pos_purchase_order_details.belongsTo(pos_raw_materials_products, { as: "pos_raw_materials_product", foreignKey: "pos_raw_materials_product_id"});
  pos_raw_materials_products.hasMany(pos_purchase_order_details, { as: "pos_purchase_order_details", foreignKey: "pos_raw_materials_product_id"});
  pos_categories.belongsTo(pos_revenue_categories, { as: "pos_revenue_category", foreignKey: "pos_revenue_category_id"});
  pos_revenue_categories.hasMany(pos_categories, { as: "pos_categories", foreignKey: "pos_revenue_category_id"});
  pos_hubs.belongsTo(pos_revenue_categorization, { as: "pos_revenue_categorization", foreignKey: "pos_revenue_categorization_id"});
  pos_revenue_categorization.hasMany(pos_hubs, { as: "pos_hubs", foreignKey: "pos_revenue_categorization_id"});
  pos_stations.belongsTo(pos_revenue_categorization, { as: "pos_revenue_categorization", foreignKey: "pos_revenue_categorization_id"});
  pos_revenue_categorization.hasMany(pos_stations, { as: "pos_stations", foreignKey: "pos_revenue_categorization_id"});
  pos_user_roles.belongsTo(pos_roles, { as: "pos_role", foreignKey: "pos_role_id"});
  pos_roles.hasMany(pos_user_roles, { as: "pos_user_roles", foreignKey: "pos_role_id"});
  pos_credit_note_details.belongsTo(pos_sale_order_details, { as: "pos_sale_order_detail", foreignKey: "pos_sale_order_detail_id"});
  pos_sale_order_details.hasMany(pos_credit_note_details, { as: "pos_credit_note_details", foreignKey: "pos_sale_order_detail_id"});
  pos_sale_order_detail_additions.belongsTo(pos_sale_order_details, { as: "pos_sale_order_detail", foreignKey: "pos_sale_order_detail_id"});
  pos_sale_order_details.hasMany(pos_sale_order_detail_additions, { as: "pos_sale_order_detail_additions", foreignKey: "pos_sale_order_detail_id"});
  pos_credit_notes.belongsTo(pos_sale_orders, { as: "pos_sale_order", foreignKey: "pos_sale_order_id"});
  pos_sale_orders.hasMany(pos_credit_notes, { as: "pos_credit_notes", foreignKey: "pos_sale_order_id"});
  pos_order_payments.belongsTo(pos_sale_orders, { as: "sale_order", foreignKey: "sale_order_id"});
  pos_sale_orders.hasMany(pos_order_payments, { as: "pos_order_payments", foreignKey: "sale_order_id"});
  pos_sale_order_details.belongsTo(pos_sale_orders, { as: "sale_order", foreignKey: "sale_order_id"});
  pos_sale_orders.hasMany(pos_sale_order_details, { as: "pos_sale_order_details", foreignKey: "sale_order_id"});
  pos_sale_orders.belongsTo(pos_station_floor_tables, { as: "pos_station_floor_table", foreignKey: "pos_station_floor_table_id"});
  pos_station_floor_tables.hasMany(pos_sale_orders, { as: "pos_sale_orders", foreignKey: "pos_station_floor_table_id"});
  pos_station_floor_tables.belongsTo(pos_station_floors, { as: "floor", foreignKey: "floor_id"});
  pos_station_floors.hasMany(pos_station_floor_tables, { as: "pos_station_floor_tables", foreignKey: "floor_id"});
  pos_accounting_periods.belongsTo(pos_stations, { as: "pos_station", foreignKey: "pos_station_id"});
  pos_stations.hasMany(pos_accounting_periods, { as: "pos_accounting_periods", foreignKey: "pos_station_id"});
  pos_agents.belongsTo(pos_stations, { as: "pos_station", foreignKey: "pos_station_id"});
  pos_stations.hasMany(pos_agents, { as: "pos_agents", foreignKey: "pos_station_id"});
  pos_budget_transfers.belongsTo(pos_stations, { as: "pos_station", foreignKey: "pos_station_id"});
  pos_stations.hasMany(pos_budget_transfers, { as: "pos_budget_transfers", foreignKey: "pos_station_id"});
  pos_cash_accounts.belongsTo(pos_stations, { as: "pos_station", foreignKey: "pos_station_id"});
  pos_stations.hasMany(pos_cash_accounts, { as: "pos_cash_accounts", foreignKey: "pos_station_id"});
  pos_categories.belongsTo(pos_stations, { as: "pos_station", foreignKey: "pos_station_id"});
  pos_stations.hasMany(pos_categories, { as: "pos_categories", foreignKey: "pos_station_id"});
  pos_coupon_categories.belongsTo(pos_stations, { as: "pos_station", foreignKey: "pos_station_id"});
  pos_stations.hasMany(pos_coupon_categories, { as: "pos_coupon_categories", foreignKey: "pos_station_id"});
  pos_credit_notes.belongsTo(pos_stations, { as: "pos_station", foreignKey: "pos_station_id"});
  pos_stations.hasMany(pos_credit_notes, { as: "pos_credit_notes", foreignKey: "pos_station_id"});
  pos_customer_categories.belongsTo(pos_stations, { as: "pos_station", foreignKey: "pos_station_id"});
  pos_stations.hasMany(pos_customer_categories, { as: "pos_customer_categories", foreignKey: "pos_station_id"});
  pos_customers.belongsTo(pos_stations, { as: "pos_station", foreignKey: "pos_station_id"});
  pos_stations.hasMany(pos_customers, { as: "pos_customers", foreignKey: "pos_station_id"});
  pos_fixed_asset_logs.belongsTo(pos_stations, { as: "synced_pos_station", foreignKey: "synced"});
  pos_stations.hasMany(pos_fixed_asset_logs, { as: "pos_fixed_asset_logs", foreignKey: "synced"});
  pos_fixed_asset_logs.belongsTo(pos_stations, { as: "from_pos_station", foreignKey: "from_pos_station_id"});
  pos_stations.hasMany(pos_fixed_asset_logs, { as: "from_pos_station_pos_fixed_asset_logs", foreignKey: "from_pos_station_id"});
  pos_fixed_asset_types.belongsTo(pos_stations, { as: "pos_station", foreignKey: "pos_station_id"});
  pos_stations.hasMany(pos_fixed_asset_types, { as: "pos_fixed_asset_types", foreignKey: "pos_station_id"});
  pos_fixed_assets.belongsTo(pos_stations, { as: "pos_station", foreignKey: "pos_station_id"});
  pos_stations.hasMany(pos_fixed_assets, { as: "pos_fixed_assets", foreignKey: "pos_station_id"});
  pos_hr_departments.belongsTo(pos_stations, { as: "pos_station", foreignKey: "pos_station_id"});
  pos_stations.hasMany(pos_hr_departments, { as: "pos_hr_departments", foreignKey: "pos_station_id"});
  pos_inventories.belongsTo(pos_stations, { as: "pos_station", foreignKey: "pos_station_id"});
  pos_stations.hasMany(pos_inventories, { as: "pos_inventories", foreignKey: "pos_station_id"});
  pos_kitchens.belongsTo(pos_stations, { as: "pos_station", foreignKey: "pos_station_id"});
  pos_stations.hasMany(pos_kitchens, { as: "pos_kitchens", foreignKey: "pos_station_id"});
  pos_level_one_chart_of_accounts.belongsTo(pos_stations, { as: "pos_station", foreignKey: "pos_station_id"});
  pos_stations.hasMany(pos_level_one_chart_of_accounts, { as: "pos_level_one_chart_of_accounts", foreignKey: "pos_station_id"});
  pos_printers.belongsTo(pos_stations, { as: "pos_station", foreignKey: "pos_station_id"});
  pos_stations.hasMany(pos_printers, { as: "pos_printers", foreignKey: "pos_station_id"});
  pos_purchase_orders.belongsTo(pos_stations, { as: "pos_station", foreignKey: "pos_station_id"});
  pos_stations.hasMany(pos_purchase_orders, { as: "pos_purchase_orders", foreignKey: "pos_station_id"});
  pos_raw_materials_categories.belongsTo(pos_stations, { as: "pos_station", foreignKey: "pos_station_id"});
  pos_stations.hasMany(pos_raw_materials_categories, { as: "pos_raw_materials_categories", foreignKey: "pos_station_id"});
  pos_reconciliation.belongsTo(pos_stations, { as: "pos_station", foreignKey: "pos_station_id"});
  pos_stations.hasMany(pos_reconciliation, { as: "pos_reconciliations", foreignKey: "pos_station_id"});
  pos_revenue_categories.belongsTo(pos_stations, { as: "pos_station", foreignKey: "pos_station_id"});
  pos_stations.hasMany(pos_revenue_categories, { as: "pos_revenue_categories", foreignKey: "pos_station_id"});
  pos_salary_item.belongsTo(pos_stations, { as: "pos_station", foreignKey: "pos_station_id"});
  pos_stations.hasMany(pos_salary_item, { as: "pos_salary_items", foreignKey: "pos_station_id"});
  pos_sale_orders.belongsTo(pos_stations, { as: "pos_station", foreignKey: "pos_station_id"});
  pos_stations.hasMany(pos_sale_orders, { as: "pos_sale_orders", foreignKey: "pos_station_id"});
  pos_share_holders.belongsTo(pos_stations, { as: "pos_station", foreignKey: "pos_station_id"});
  pos_stations.hasMany(pos_share_holders, { as: "pos_share_holders", foreignKey: "pos_station_id"});
  pos_station_floors.belongsTo(pos_stations, { as: "pos_station", foreignKey: "pos_station_id"});
  pos_stations.hasMany(pos_station_floors, { as: "pos_station_floors", foreignKey: "pos_station_id"});
  pos_stations_price_list.belongsTo(pos_stations, { as: "pos_station", foreignKey: "pos_station_id"});
  pos_stations.hasMany(pos_stations_price_list, { as: "pos_stations_price_lists", foreignKey: "pos_station_id"});
  pos_subledger_account_subaccounts.belongsTo(pos_stations, { as: "pos_station", foreignKey: "pos_station_id"});
  pos_stations.hasMany(pos_subledger_account_subaccounts, { as: "pos_subledger_account_subaccounts", foreignKey: "pos_station_id"});
  pos_subledger_parent_accounts.belongsTo(pos_stations, { as: "pos_station", foreignKey: "pos_station_id"});
  pos_stations.hasMany(pos_subledger_parent_accounts, { as: "pos_subledger_parent_accounts", foreignKey: "pos_station_id"});
  pos_subscriptions.belongsTo(pos_stations, { as: "pos_station", foreignKey: "pos_station_id"});
  pos_stations.hasMany(pos_subscriptions, { as: "pos_subscriptions", foreignKey: "pos_station_id"});
  pos_suppliers.belongsTo(pos_stations, { as: "pos_station", foreignKey: "pos_station_id"});
  pos_stations.hasMany(pos_suppliers, { as: "pos_suppliers", foreignKey: "pos_station_id"});
  pos_users.belongsTo(pos_stations, { as: "pos_station", foreignKey: "pos_station_id"});
  pos_stations.hasMany(pos_users, { as: "pos_users", foreignKey: "pos_station_id"});
  pos_price_list_products.belongsTo(pos_stations_price_list, { as: "pos_station_price_list", foreignKey: "pos_station_price_list_id"});
  pos_stations_price_list.hasMany(pos_price_list_products, { as: "pos_price_list_products", foreignKey: "pos_station_price_list_id"});
  pos_station_price_list_type.belongsTo(pos_stations_price_list, { as: "pos_stations_price_list", foreignKey: "pos_stations_price_list_id"});
  pos_stations_price_list.hasMany(pos_station_price_list_type, { as: "pos_station_price_list_types", foreignKey: "pos_stations_price_list_id"});
  pos_subledger_accounts.belongsTo(pos_subledger, { as: "pos_subledger", foreignKey: "pos_subledger_id"});
  pos_subledger.hasMany(pos_subledger_accounts, { as: "pos_subledger_accounts", foreignKey: "pos_subledger_id"});
  pos_subledger_parent_accounts.belongsTo(pos_subledger, { as: "pos_subledger", foreignKey: "pos_subledger_id"});
  pos_subledger.hasMany(pos_subledger_parent_accounts, { as: "pos_subledger_parent_accounts", foreignKey: "pos_subledger_id"});
  pos_subledger_transactions.belongsTo(pos_subledger, { as: "pos_subledger", foreignKey: "pos_subledger_id"});
  pos_subledger.hasMany(pos_subledger_transactions, { as: "pos_subledger_transactions", foreignKey: "pos_subledger_id"});
  pos_agents.belongsTo(pos_subledger_account_subaccounts, { as: "prepayments_subaccount", foreignKey: "prepayments_subaccount_id"});
  pos_subledger_account_subaccounts.hasMany(pos_agents, { as: "pos_agents", foreignKey: "prepayments_subaccount_id"});
  pos_agents.belongsTo(pos_subledger_account_subaccounts, { as: "payable_subaccount", foreignKey: "payable_subaccount_id"});
  pos_subledger_account_subaccounts.hasMany(pos_agents, { as: "payable_subaccount_pos_agents", foreignKey: "payable_subaccount_id"});
  pos_customers.belongsTo(pos_subledger_account_subaccounts, { as: "unearned_subaccount", foreignKey: "unearned_subaccount_id"});
  pos_subledger_account_subaccounts.hasMany(pos_customers, { as: "pos_customers", foreignKey: "unearned_subaccount_id"});
  pos_customers.belongsTo(pos_subledger_account_subaccounts, { as: "receivable_subaccount", foreignKey: "receivable_subaccount_id"});
  pos_subledger_account_subaccounts.hasMany(pos_customers, { as: "receivable_subaccount_pos_customers", foreignKey: "receivable_subaccount_id"});
  pos_hr_employees.belongsTo(pos_subledger_account_subaccounts, { as: "salaries_payable_subaccount", foreignKey: "salaries_payable_subaccount_id"});
  pos_subledger_account_subaccounts.hasMany(pos_hr_employees, { as: "pos_hr_employees", foreignKey: "salaries_payable_subaccount_id"});
  pos_subledger_transactions.belongsTo(pos_subledger_account_subaccounts, { as: "pos_subledger_subaccount", foreignKey: "pos_subledger_subaccounts_id"});
  pos_subledger_account_subaccounts.hasMany(pos_subledger_transactions, { as: "pos_subledger_transactions", foreignKey: "pos_subledger_subaccounts_id"});
  pos_suppliers.belongsTo(pos_subledger_account_subaccounts, { as: "prepayments_subaccount", foreignKey: "prepayments_subaccount_id"});
  pos_subledger_account_subaccounts.hasMany(pos_suppliers, { as: "pos_suppliers", foreignKey: "prepayments_subaccount_id"});
  pos_suppliers.belongsTo(pos_subledger_account_subaccounts, { as: "payable_subaccount", foreignKey: "payable_subaccount_id"});
  pos_subledger_account_subaccounts.hasMany(pos_suppliers, { as: "payable_subaccount_pos_suppliers", foreignKey: "payable_subaccount_id"});
  pos_subledger_account_subaccounts.belongsTo(pos_subledger_accounts, { as: "pos_subledger_account", foreignKey: "pos_subledger_account_id"});
  pos_subledger_accounts.hasMany(pos_subledger_account_subaccounts, { as: "pos_subledger_account_subaccounts", foreignKey: "pos_subledger_account_id"});
  pos_subscriptions.belongsTo(pos_subscriptions, { as: "upgrade_from_pos_subscription", foreignKey: "upgrade_from_pos_subscription_id"});
  pos_subscriptions.hasMany(pos_subscriptions, { as: "pos_subscriptions", foreignKey: "upgrade_from_pos_subscription_id"});
  pos_fixed_assets.belongsTo(pos_suppliers, { as: "pos_supplier", foreignKey: "pos_supplier_id"});
  pos_suppliers.hasMany(pos_fixed_assets, { as: "pos_fixed_assets", foreignKey: "pos_supplier_id"});
  pos_purchase_orders.belongsTo(pos_suppliers, { as: "supplier", foreignKey: "supplier_id"});
  pos_suppliers.hasMany(pos_purchase_orders, { as: "pos_purchase_orders", foreignKey: "supplier_id"});
  pos_transaction_details.belongsTo(pos_transactions, { as: "pos_transaction", foreignKey: "pos_transaction_id"});
  pos_transactions.hasMany(pos_transaction_details, { as: "pos_transaction_details", foreignKey: "pos_transaction_id"});
  pos_hubs.belongsTo(pos_types, { as: "pos_type", foreignKey: "pos_type_id"});
  pos_types.hasMany(pos_hubs, { as: "pos_hubs", foreignKey: "pos_type_id"});
  pos_stations.belongsTo(pos_types, { as: "pos_type", foreignKey: "pos_type_id"});
  pos_types.hasMany(pos_stations, { as: "pos_stations", foreignKey: "pos_type_id"});
  pos_budget_transfers.belongsTo(pos_users, { as: "pos_user", foreignKey: "pos_user_id"});
  pos_users.hasMany(pos_budget_transfers, { as: "pos_budget_transfers", foreignKey: "pos_user_id"});
  pos_hr_departments.belongsTo(pos_users, { as: "manager_user", foreignKey: "manager_user_id"});
  pos_users.hasMany(pos_hr_departments, { as: "pos_hr_departments", foreignKey: "manager_user_id"});
  pos_order_payments.belongsTo(pos_users, { as: "pos_user", foreignKey: "pos_user_id"});
  pos_users.hasMany(pos_order_payments, { as: "pos_order_payments", foreignKey: "pos_user_id"});
  pos_reconciliation.belongsTo(pos_users, { as: "receiver_pos_user", foreignKey: "receiver_pos_user_id"});
  pos_users.hasMany(pos_reconciliation, { as: "pos_reconciliations", foreignKey: "receiver_pos_user_id"});
  pos_reconciliation.belongsTo(pos_users, { as: "pos_user", foreignKey: "pos_user_id"});
  pos_users.hasMany(pos_reconciliation, { as: "pos_user_pos_reconciliations", foreignKey: "pos_user_id"});
  pos_sale_orders.belongsTo(pos_users, { as: "creater_waiter", foreignKey: "creater_waiter_id"});
  pos_users.hasMany(pos_sale_orders, { as: "pos_sale_orders", foreignKey: "creater_waiter_id"});
  pos_sale_orders.belongsTo(pos_users, { as: "pos_user", foreignKey: "pos_user_id"});
  pos_users.hasMany(pos_sale_orders, { as: "pos_user_pos_sale_orders", foreignKey: "pos_user_id"});
  pos_user_roles.belongsTo(pos_users, { as: "pos_user", foreignKey: "pos_user_id"});
  pos_users.hasMany(pos_user_roles, { as: "pos_user_roles", foreignKey: "pos_user_id"});
  pos_users.belongsTo(pos_users, { as: "reconciliation_pos_user", foreignKey: "reconciliation_pos_user_id"});
  pos_users.hasMany(pos_users, { as: "pos_users", foreignKey: "reconciliation_pos_user_id"});
  subscription_packages_features.belongsTo(subscription_features, { as: "subscription_feature", foreignKey: "subscription_feature_id"});
  subscription_features.hasMany(subscription_packages_features, { as: "subscription_packages_features", foreignKey: "subscription_feature_id"});
  subscription_packages_features.belongsTo(subscription_packages, { as: "subscription_package", foreignKey: "subscription_package_id"});
  subscription_packages.hasMany(subscription_packages_features, { as: "subscription_packages_features", foreignKey: "subscription_package_id"});
  topic_chats.belongsTo(topics, { as: "topic", foreignKey: "topic_id"});
  topics.hasMany(topic_chats, { as: "topic_chats", foreignKey: "topic_id"});

  return {
    intermed,
    monthly_deduction_details,
    pos_accounting_periods,
    pos_agents,
    pos_break_units_logs,
    pos_budget,
    pos_budget_transfers,
    pos_cash_accounts,
    pos_categories,
    pos_cheques,
    pos_coupon_categories,
    pos_coupons,
    pos_credit_note_details,
    pos_credit_notes,
    pos_customer_categories,
    pos_customers,
    pos_deleted_data,
    pos_fixed_asset_logs,
    pos_fixed_asset_types,
    pos_fixed_assets,
    pos_hr_attendance,
    pos_hr_award_types,
    pos_hr_awards,
    pos_hr_complain_types,
    pos_hr_complains,
    pos_hr_department_kpis,
    pos_hr_departments,
    pos_hr_emp_salary_items,
    pos_hr_employee_departments,
    pos_hr_employee_files,
    pos_hr_employee_kpi_records,
    pos_hr_employee_transfers,
    pos_hr_employee_warnings,
    pos_hr_employees,
    pos_hr_employees_working_hours,
    pos_hr_holiday_departments,
    pos_hr_holidays,
    pos_hr_job_titles,
    pos_hr_leave_types,
    pos_hr_leaves,
    pos_hr_monthly_salaries,
    pos_hr_monthly_salary_details,
    pos_hr_salary_items,
    pos_hr_tax_levels,
    pos_hr_weekdays,
    pos_hub_features,
    pos_hub_packages,
    pos_hub_packages_features,
    pos_hub_subscriptions,
    pos_hubs,
    pos_inventories,
    pos_inventory_items,
    pos_inventory_layers,
    pos_inventory_transfer_details,
    pos_inventory_transfers,
    pos_job_titles,
    pos_kitchen_products,
    pos_kitchens,
    pos_level_one_chart_of_accounts,
    pos_level_three_chart_of_accounts,
    pos_level_two_chart_of_accounts,
    pos_main_chart_of_accounts_types,
    pos_order_payments,
    pos_price_list_products,
    pos_printers,
    pos_product_additions,
    pos_product_unit_customer_categories,
    pos_product_units,
    pos_products,
    pos_purchase_item_types,
    pos_purchase_order_details,
    pos_purchase_orders,
    pos_raw_materials_categories,
    pos_raw_materials_products,
    pos_reconciliation,
    pos_revenue_categories,
    pos_revenue_categorization,
    pos_roles,
    pos_salary_deduction,
    pos_salary_item,
    pos_salary_items_types,
    pos_sale_order_detail_additions,
    pos_sale_order_details,
    pos_sale_orders,
    pos_share_holders,
    pos_station_floor_tables,
    pos_station_floors,
    pos_station_floors_shalves,
    pos_station_price_list_type,
    pos_stations,
    pos_stations_price_list,
    pos_subledger,
    pos_subledger_account_subaccounts,
    pos_subledger_accounts,
    pos_subledger_parent_accounts,
    pos_subledger_transactions,
    pos_subscriptions,
    pos_suppliers,
    pos_transaction_details,
    pos_transactions,
    pos_types,
    pos_user_roles,
    pos_users,
    subscription_features,
    subscription_packages,
    subscription_packages_features,
    tables_sync,
    topic_chats,
    topics,
  };
}
module.exports = initModels;
module.exports.initModels = initModels;
module.exports.default = initModels;

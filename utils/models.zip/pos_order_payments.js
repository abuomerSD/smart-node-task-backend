const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pos_order_payments', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    pos_user_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'pos_users',
        key: 'id'
      }
    },
    sale_order_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_sale_orders',
        key: 'id'
      }
    },
    pos_cash_account_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_cash_accounts',
        key: 'id'
      }
    },
    payment_type: {
      type: DataTypes.STRING(4),
      allowNull: true
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    amount: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    bill_image: {
      type: DataTypes.STRING(300),
      allowNull: true
    },
    discount: {
      type: DataTypes.DECIMAL,
      allowNull: true,
      defaultValue: 0.00
    },
    created: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'pos_order_payments',
    timestamps: false,
    indexes: [
      {
        name: "pos_user_id",
        fields: [
          { name: "pos_user_id" },
        ]
      },
      {
        name: "pos_user_id_1",
        fields: [
          { name: "pos_user_id" },
        ]
      },
      {
        name: "sale_order_id",
        fields: [
          { name: "sale_order_id" },
        ]
      },
    ]
  });
};

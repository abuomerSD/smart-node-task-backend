const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('subscription_packages_features', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    subscription_feature_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'subscription_features',
        key: 'id'
      }
    },
    subscription_package_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'subscription_packages',
        key: 'id'
      }
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    created: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'subscription_packages_features',
    timestamps: false,
    indexes: [
      {
        name: "subscription_feature_id",
        fields: [
          { name: "subscription_feature_id" },
        ]
      },
      {
        name: "subscription_package_id",
        fields: [
          { name: "subscription_package_id" },
        ]
      },
    ]
  });
};

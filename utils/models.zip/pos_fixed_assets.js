const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pos_fixed_assets', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    pos_fixed_asset_type_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'pos_fixed_asset_types',
        key: 'id'
      }
    },
    pos_supplier_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_suppliers',
        key: 'id'
      }
    },
    name: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    name_en: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    pos_station_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_stations',
        key: 'id'
      }
    },
    initial_book_value: {
      type: DataTypes.DECIMAL,
      allowNull: false
    },
    salvage_value: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    useful_life_years: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    installation_date: {
      type: DataTypes.DATEONLY,
      allowNull: true
    },
    disposed: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 0
    },
    under_warranty: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 0
    },
    warranty_exp: {
      type: DataTypes.DATEONLY,
      allowNull: true
    },
    comment: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    created: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'pos_fixed_assets',
    timestamps: false,
    indexes: [
      {
        name: "agent_id_ikji",
        fields: [
          { name: "pos_supplier_id" },
        ]
      },
      {
        name: "fixed_asset_type_id_fhj",
        fields: [
          { name: "pos_fixed_asset_type_id" },
        ]
      },
    ]
  });
};

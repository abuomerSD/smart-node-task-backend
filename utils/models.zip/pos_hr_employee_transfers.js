const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pos_hr_employee_transfers', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    pos_hr_employee_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_hr_employees',
        key: 'id'
      }
    },
    from_pos_hr_department_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_hr_departments',
        key: 'id'
      }
    },
    to_pos_hr_department_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_hr_departments',
        key: 'id'
      }
    },
    from_salary: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    to_salary: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    date: {
      type: DataTypes.DATEONLY,
      allowNull: true
    },
    created: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'pos_hr_employee_transfers',
    timestamps: false,
    indexes: [
      {
        name: "fk_pos_hr_employee_transfers_pos_hr_departments_1",
        fields: [
          { name: "from_pos_hr_department_id" },
        ]
      },
      {
        name: "fk_pos_hr_employee_transfers_pos_hr_departments_2",
        fields: [
          { name: "to_pos_hr_department_id" },
        ]
      },
      {
        name: "fk_pos_hr_employee_transfers_pos_hr_employees_1",
        fields: [
          { name: "pos_hr_employee_id" },
        ]
      },
    ]
  });
};

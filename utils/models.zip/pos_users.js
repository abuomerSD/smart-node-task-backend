const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pos_users', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    pos_station_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_stations',
        key: 'id'
      }
    },
    pos_bank_cash_account_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_cash_accounts',
        key: 'id'
      }
    },
    pos_cash_cash_account_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_cash_accounts',
        key: 'id'
      }
    },
    reconciliation_pos_user_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_users',
        key: 'id'
      }
    },
    pos_printer_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_printers',
        key: 'id'
      }
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    name: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    email: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    pass: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    tel: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    created: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'pos_users',
    timestamps: false,
    indexes: [
      {
        name: "pos_bank_cash_account_id",
        fields: [
          { name: "pos_bank_cash_account_id" },
        ]
      },
      {
        name: "pos_cash_cash_account_id",
        fields: [
          { name: "pos_cash_cash_account_id" },
        ]
      },
      {
        name: "reconciliation_pos_user_id",
        fields: [
          { name: "reconciliation_pos_user_id" },
        ]
      },
    ]
  });
};

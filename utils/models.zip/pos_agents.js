const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pos_agents', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    pos_station_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'pos_stations',
        key: 'id'
      }
    },
    name: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    name_en: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    address: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    phone: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    payable_subaccount_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_subledger_account_subaccounts',
        key: 'id'
      }
    },
    prepayments_subaccount_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_subledger_account_subaccounts',
        key: 'id'
      }
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    created: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'pos_agents',
    timestamps: false,
    indexes: [
      {
        name: "payable_sub_account_id",
        fields: [
          { name: "payable_subaccount_id" },
        ]
      },
      {
        name: "prepayments_sub_account_id",
        fields: [
          { name: "prepayments_subaccount_id" },
        ]
      },
    ]
  });
};

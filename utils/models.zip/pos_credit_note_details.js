const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pos_credit_note_details', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    pos_credit_note_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_credit_notes',
        key: 'id'
      }
    },
    pos_sale_order_detail_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_sale_order_details',
        key: 'id'
      }
    },
    qty: {
      type: DataTypes.DECIMAL,
      allowNull: false
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 0
    },
    created: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'pos_credit_note_details',
    timestamps: false,
    indexes: [
      {
        name: "pos_credit_note_details_ibfk_1",
        fields: [
          { name: "pos_credit_note_id" },
        ]
      },
      {
        name: "pos_sale_order_detail_id",
        fields: [
          { name: "pos_sale_order_detail_id" },
        ]
      },
    ]
  });
};

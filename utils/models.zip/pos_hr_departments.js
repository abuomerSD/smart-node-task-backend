const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pos_hr_departments', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    pos_station_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_stations',
        key: 'id'
      }
    },
    manager_user_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_users',
        key: 'id'
      }
    },
    name: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    descr: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    acceptable_kpis_average: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    created: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'pos_hr_departments',
    timestamps: false,
    indexes: [
      {
        name: "fk_pos_hr_departments_pos_stations_1",
        fields: [
          { name: "pos_station_id" },
        ]
      },
      {
        name: "fk_pos_hr_departments_pos_users_1",
        fields: [
          { name: "manager_user_id" },
        ]
      },
    ]
  });
};

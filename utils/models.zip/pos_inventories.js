const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pos_inventories', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    pos_hub_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    pos_station_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_stations',
        key: 'id'
      }
    },
    pos_kitchen_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_kitchens',
        key: 'id'
      }
    },
    name: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    location: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    is_main: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 0
    },
    created: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'pos_inventories',
    timestamps: false,
    indexes: [
      {
        name: "pos_kitchen_id",
        fields: [
          { name: "pos_kitchen_id" },
        ]
      },
    ]
  });
};

const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pos_sale_order_detail_additions', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    pos_sale_order_detail_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'pos_sale_order_details',
        key: 'id'
      }
    },
    pos_product_addition_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'pos_product_additions',
        key: 'id'
      }
    },
    price: {
      type: DataTypes.DECIMAL,
      allowNull: false
    },
    created: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'pos_sale_order_detail_additions',
    timestamps: false,
    indexes: [
      {
        name: "pos_product_addition_id",
        fields: [
          { name: "pos_product_addition_id" },
        ]
      },
      {
        name: "pos_sale_order_detail_additions_ibfk_2",
        fields: [
          { name: "pos_sale_order_detail_id" },
        ]
      },
    ]
  });
};

const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pos_categories', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    pos_hub_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_hubs',
        key: 'id'
      }
    },
    pos_station_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_stations',
        key: 'id'
      }
    },
    pos_revenue_category_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_revenue_categories',
        key: 'id'
      }
    },
    name: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    img: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    created: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'pos_categories',
    timestamps: false,
    indexes: [
      {
        name: "pos_categories_ibfk_3",
        fields: [
          { name: "pos_revenue_category_id" },
        ]
      },
      {
        name: "pos_hub_id",
        fields: [
          { name: "pos_hub_id" },
        ]
      },
      {
        name: "pos_hub_id_1",
        fields: [
          { name: "pos_hub_id" },
        ]
      },
    ]
  });
};

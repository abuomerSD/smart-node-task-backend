const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pos_hr_awards', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    pos_hr_employee_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_hr_employees',
        key: 'id'
      }
    },
    pos_hr_award_type_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_hr_award_types',
        key: 'id'
      }
    },
    descr: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    total_amount: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    paid_amount: {
      type: DataTypes.DECIMAL,
      allowNull: true,
      defaultValue: 0.00
    },
    month: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    year: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    general_manager_approve: {
      type: DataTypes.TINYINT,
      allowNull: true
    },
    created: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'pos_hr_awards',
    timestamps: false,
    indexes: [
      {
        name: "fk_pos_hr_awards_pos_hr_award_types_1",
        fields: [
          { name: "pos_hr_award_type_id" },
        ]
      },
      {
        name: "fk_pos_hr_awards_pos_hr_employees_1",
        fields: [
          { name: "pos_hr_employee_id" },
        ]
      },
    ]
  });
};

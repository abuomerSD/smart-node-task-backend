const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pos_break_units_logs', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    pos_inventory_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_inventories',
        key: 'id'
      }
    },
    from_unit_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_product_units',
        key: 'id'
      }
    },
    to_unit_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_product_units',
        key: 'id'
      }
    },
    qty: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    created: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'pos_break_units_logs',
    timestamps: false,
    indexes: [
      {
        name: "from_unit_id",
        fields: [
          { name: "from_unit_id" },
        ]
      },
      {
        name: "pos_inventory_id",
        fields: [
          { name: "pos_inventory_id" },
        ]
      },
      {
        name: "to_unit",
        fields: [
          { name: "to_unit_id" },
        ]
      },
    ]
  });
};

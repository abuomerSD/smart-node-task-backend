const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('pos_hubs', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    server_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    pos_hub_manager_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    pos_hub_admin_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    marketing_campaign_team_member_id: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    pos_revenue_categorization_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_revenue_categorization',
        key: 'id'
      }
    },
    pos_type_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'pos_types',
        key: 'id'
      }
    },
    name: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    has_partners: {
      type: DataTypes.TINYINT,
      allowNull: true
    },
    single_products_list: {
      type: DataTypes.TINYINT,
      allowNull: true
    },
    centeric_ineventory: {
      type: DataTypes.TINYINT,
      allowNull: true
    },
    centeric_products: {
      type: DataTypes.TINYINT,
      allowNull: true
    },
    synced: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    created: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    updated: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'pos_hubs',
    timestamps: false,
    indexes: [
      {
        name: "pos_revenue_categorization_id",
        fields: [
          { name: "pos_revenue_categorization_id" },
        ]
      },
      {
        name: "pos_type_id",
        fields: [
          { name: "pos_type_id" },
        ]
      },
    ]
  });
};
